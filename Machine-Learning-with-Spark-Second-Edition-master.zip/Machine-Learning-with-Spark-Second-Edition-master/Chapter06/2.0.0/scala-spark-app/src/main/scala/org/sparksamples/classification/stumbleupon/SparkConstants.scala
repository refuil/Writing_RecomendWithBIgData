package org.sparksamples.classification.stumbleupon

/**
  * Created by manpreet.singh on 26/04/16.
  */
object SparkConstants {

  val SparkMaster = "local[1]"

}
