package linalg.fields

/**
  * Created by manpreet.singh on 27/01/16.
  */
object GaloisField {

  // GF2 operations
  def GaloisField2(): Unit = {
    println(Zero + Zero)
    println(One + Zero)
    println(One + One)
  }

  def main(args: Array[String]) {
    GaloisField2()
  }

}
