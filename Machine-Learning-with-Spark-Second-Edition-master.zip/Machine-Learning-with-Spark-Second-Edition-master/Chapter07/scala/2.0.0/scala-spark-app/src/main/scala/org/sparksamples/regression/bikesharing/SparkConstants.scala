package org.sparksamples.regression.bikesharing

/**
  * Created by manpreet.singh on 26/04/16.
  */
object SparkConstants {

  val SparkMaster = "local[1]"

}
